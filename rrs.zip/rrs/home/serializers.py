# create restframework serializers  
"""
This module contains the serializer classes for our REST API.  These are used to convert between Python objects and JSON format when we send data to
This is the Serializer for our User model.  It will be used to convert a User object into JSON and vice versa when we interact
Serializer for user model.
"""


# from rest_framework import serializers
# from django.contrib.auth.models import User
# from .models import *

# class bookingserializer(serializers.ModelSerializer):
#     class Meta:
#         model = 

    